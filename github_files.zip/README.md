# ⭐ Star Shop Bot

Telegram Stars, Premium va Sovg'alar sotish uchun bot.

---

## 🚀 Railway.app ga deploy qilish

### 1. GitHub ga yuklash

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/SIZNING_USERNAME/REPO_NOMI.git
git push -u origin main
```

### 2. Railway.app sozlamalari

1. [railway.app](https://railway.app) ga kiring
2. **New Project → Deploy from GitHub repo** bosing
3. Reponi tanlang
4. **Variables** bo'limiga o'ting va quyidagi o'zgaruvchilarni kiriting:

| O'zgaruvchi | Qiymat | Misol |
|---|---|---|
| `BOT_TOKEN` | Bot tokeni | `1234567890:AAF...` |
| `ADMIN_ID` | Admin Telegram ID | `123456789` |
| `CHAT_ID` | Guruh/kanal ID | `-1001234567890` |
| `CARD_NUMBER` | Karta raqami | `5614 6803 7065 8706` |
| `ADMIN_USERNAME` | Admin username | `@YourUsername` |
| `SUPPORT_USERNAMES` | Qo'llab-quvvatlash | `username1,username2` |
| `REVIEW_CHANNEL_ID` | Sharh kanali ID | `-1001234567890` |

5. **Deploy** tugmasini bosing ✅

---

## 💻 Lokal ishga tushirish

```bash
# 1. .env fayl yarating
cp .env.example .env
# .env faylni oching va haqiqiy qiymatlar kiriting

# 2. Kerakli kutubxonalarni o'rnating
pip install -r requirements.txt

# 3. Botni ishga tushiring
python bot.py
```

---

## ⚠️ Muhim eslatmalar

- `.env` fayli **hech qachon** GitHub ga yuklanmasin (`.gitignore` da himoyalangan)
- `orders.json` va `users.json` fayllari Railway da ishga tushganda avtomatik yaratiladi
- Railway restart bo'lganda JSON fayllar o'chiriladi — doimiy saqlash uchun **Railway Volume** yoki tashqi DB (MongoDB, PostgreSQL) ishlating

---

## 📦 Fayl tuzilmasi

```
├── bot.py              # Asosiy bot kodi
├── requirements.txt    # Python kutubxonalari
├── Procfile            # Railway ishga tushirish buyrug'i
├── .gitignore          # GitHub ga yuklanmaydigan fayllar
├── .env.example        # Namuna environment o'zgaruvchilar
└── README.md           # Ushbu fayl
```
